# mlb_risp_alert_app.py

from flask import Flask, render_template_string, request, jsonify, redirect, url_for
import threading
import time
import requests

app = Flask(__name__)

GAMES = {}
MONITORING = {}
TEST_MODE = False

TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>MLB Game Alert Setup</title>
    <style>
        .green-dot {
            width: 10px;
            height: 10px;
            background-color: limegreen;
            border-radius: 50%;
            animation: blink 1s infinite;
            display: inline-block;
            margin-left: 10px;
        }
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0; }
            100% { opacity: 1; }
        }
        .banner {
            padding: 10px;
            background-color: #e0ffe0;
            border: 1px solid #00aa00;
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>Select Games and Alert Conditions <span class='green-dot'></span></h2>
    {% if started %}
        <div class='banner'>✅ Monitoring started! Live alerts will appear below.</div>
    {% endif %}
    {% if not games %}
        <div style='color: red; font-weight: bold;'>⚠️ No live games found. Try again later or use Test Mode.</div>
    {% endif %}
    <form method='post' action='/start'>
        {% for label, gid in games.items() %}
            <input type='checkbox' name='games' value='{{ gid }}'> {{ label }}<br>
        {% endfor %}
        <br>
        <label><input type='checkbox' name='conditions' value='second_and_third_no_outs' checked> 2nd & 3rd, 0 Outs</label><br>
        <label><input type='checkbox' name='conditions' value='risp_any_out' checked> RISP (2nd or 3rd), Any Outs</label><br>
        <label><input type='checkbox' name='conditions' value='bases_loaded_two_outs'> Bases Loaded, 2 Outs</label><br>
        <label><input type='checkbox' name='conditions' value='all_hits'> All Hits</label><br><br>
        <button type='submit'>Start Monitoring</button>
    </form>
    <br>
    <form method='post' action='/test'>
        <button type='submit'>Trigger Test Alert</button>
    </form>
    <form method='post' action='/testmode'>
        <button type='submit'>▶ Enable Fake Game Mode</button>
    </form>
    <br>
    <h3>Live Alerts:</h3>
    <pre id='log'></pre>
    <script>
        setInterval(() => {
            fetch('/log').then(res => res.json()).then(data => {
                document.getElementById('log').textContent = data.join('\n');
            });
        }, 3000);
    </script>
</body>
</html>
"""

LOG = []

def log(msg):
    print(msg)
    LOG.append(msg)
    if len(LOG) > 50:
        LOG.pop(0)

def get_today_games():
    if TEST_MODE:
        return {"Fake Team A @ Fake Team B": "TEST_GAME"}
    try:
        url = "https://statsapi.mlb.com/api/v1/schedule?sportId=1"
        res = requests.get(url).json()
        ids = {}
        for date in res.get("dates", []):
            for g in date.get("games", []):
                home = g["teams"]["home"]["team"]["name"]
                away = g["teams"]["away"]["team"]["name"]
                label = f"{away} @ {home}"
                ids[label] = g["gamePk"]
        return ids
    except Exception as e:
        log(f"Error fetching games: {e}")
        return {}

def monitor(game_id, label, selected_conditions):
    seen = set()
    log(f"🔍 Starting monitor for {label}...")
    while MONITORING.get(game_id):
        try:
            if TEST_MODE:
                log(f"{label} — TEST MODE ▶ HIT by Demo Player: Double ▶ Simulated hit event.")
                log(f"{label} — TEST MODE ▶ RISP! ▶ Simulated runners on base.")
                time.sleep(10)
                continue

            url = f"https://statsapi.mlb.com/api/v1.1/game/{game_id}/feed/live"
            data = requests.get(url).json()
            plays = data.get("liveData", {}).get("plays", {}).get("allPlays", [])
            log(f"{label} — {len(plays)} plays checked.")
            for play in plays:
                pid = play.get("playId")
                if pid in seen: continue
                runners = play.get("start", {}).get("runners", [])
                bases = {r["base"] for r in runners if "base" in r}
                outs = play.get("count", {}).get("outs", -1)
                event = play.get("result", {}).get("event", "")
                desc = play.get("result", {}).get("description", "")

                if "second_and_third_no_outs" in selected_conditions:
                    if {"second", "third"}.issubset(bases) and "first" not in bases and outs == 0:
                        log(f"{label} — 2nd & 3rd, 0 OUTS! ▶ {desc}")

                if "risp_any_out" in selected_conditions:
                    if "second" in bases or "third" in bases:
                        log(f"{label} — RISP! ▶ {desc} ({outs} outs)")

                if "bases_loaded_two_outs" in selected_conditions:
                    if {"first", "second", "third"}.issubset(bases) and outs == 2:
                        log(f"{label} — BASES LOADED, 2 OUTS! ▶ {desc}")

                if "all_hits" in selected_conditions:
                    if event in ["Single", "Double", "Triple", "Home Run"]:
                        batter = play.get("matchup", {}).get("batter", {}).get("fullName", "")
                        log(f"{label} — HIT by {batter}: {event} ▶ {desc}")

                seen.add(pid)
        except Exception as e:
            log(f"Error in {label}: {e}")
        time.sleep(15)

@app.route("/")
def index():
    global GAMES
    GAMES = get_today_games()
    started = request.args.get("started") == "1"
    return render_template_string(TEMPLATE, games=GAMES, started=started)

@app.route("/start", methods=["POST"])
def start():
    selected_games = request.form.getlist("games")
    selected_conditions = request.form.getlist("conditions")
    for gid in selected_games:
        if gid not in MONITORING:
            label = next((lbl for lbl, pk in GAMES.items() if str(pk) == gid), gid)
            MONITORING[gid] = True
            threading.Thread(target=monitor, args=(gid, label, selected_conditions), daemon=True).start()
    return redirect(url_for("index", started=1))

@app.route("/test", methods=["POST"])
def test_trigger():
    log("🔔 Test Alert: This is a test notification from your MLB monitoring system.")
    return "<p>Test alert sent! <a href='/'>Go back</a></p>"

@app.route("/testmode", methods=["POST"])
def enable_test_mode():
    global TEST_MODE
    TEST_MODE = True
    log("✅ TEST MODE ENABLED — fake alerts will now be shown.")
    return redirect(url_for("index", started=1))

@app.route("/log")
def get_log():
    return jsonify(LOG)

if __name__ == '__main__':
    app.run(debug=False, port=5050)
